namespace Dpay.Client.Models
{
    public class Extra
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}