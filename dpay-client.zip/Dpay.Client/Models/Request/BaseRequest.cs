﻿
namespace Dpay.Client.Models.Request
{
    public class BaseRequest
    {
        public string ApiKey { get; set; }
    }
}
