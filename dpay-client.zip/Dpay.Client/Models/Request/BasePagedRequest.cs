﻿
namespace Dpay.Client.Models.Request
{
    public class BasePagedRequest : BaseRequest
    {
        public PagerInputModel PagerInputDto { get; set; }
    }
}
