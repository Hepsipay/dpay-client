﻿
namespace Dpay.Client.Models.Request
{
    public class GetInstallmentsRequest : BaseRequest
    {
        public string BinNumber { get; set; }
    }
}
