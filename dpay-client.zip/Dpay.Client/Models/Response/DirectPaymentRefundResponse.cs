﻿namespace Dpay.Client.Models.Response
{
    public class DirectPaymentRefundResponse : BaseResponse
    {
    }
}
