﻿namespace Dpay.Client.Models.Response
{
    public class CreateThreedResponse : BaseResponse
    {
        public string HtmlForm { get; set; }
    }
}