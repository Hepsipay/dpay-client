﻿namespace Dpay.Client.Models
{
    public enum PaymentMethod
    {
        None = 0,
        PayAtDoor = 1,
        MoneyOrder = 2
    }
}