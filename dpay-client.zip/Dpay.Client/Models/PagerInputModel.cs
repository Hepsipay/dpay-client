﻿
namespace Dpay.Client.Models
{
    public class PagerInputModel
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }
}
