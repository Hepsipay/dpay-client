﻿namespace Dpay.Client.Models
{
    public enum FraudState
    {
        None = 0,
        Approved = 1,
        Declined = 2,
        Challenged = 3
    }
}