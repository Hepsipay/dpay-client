﻿namespace Dpay.Client.Web.Models
{
    public class ThreedSuccessfulResultModel
    {
        public string EncryptedThreedResult { get; set; }
    }
}