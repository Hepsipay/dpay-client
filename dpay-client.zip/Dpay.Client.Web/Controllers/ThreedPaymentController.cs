﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dpay.Client.Models;
using Dpay.Client.Models.Request;
using Dpay.Client.Processors.Impl;
using Dpay.Client.Processors.Interfaces;
using Dpay.Client.Web.Models;

namespace Dpay.Client.Web.Controllers
{
    public class ThreedPaymentController : Controller
    {
        private readonly IPaymentProcessor _paymentProcessor;

        private readonly string _apiKey;
        private readonly string _secretKey;
        private readonly string _hashVersion;
        private readonly string _baseUrl;
        private readonly string _apiUrl;
        private readonly string _hepsipayUrl;

        public ThreedPaymentController()
        {
            _paymentProcessor = new PaymentProcessor();
            _apiKey = ConfigurationManager.AppSettings["ApiKey"];
            _secretKey = ConfigurationManager.AppSettings["SecretKey"];
            _hashVersion = ConfigurationManager.AppSettings["HashVersion"];
            _baseUrl = ConfigurationManager.AppSettings["ReturnBaseUrl"];
            _apiUrl = ConfigurationManager.AppSettings["ApiUrl"];
            _hepsipayUrl = ConfigurationManager.AppSettings["HepsipayUrl"];
        }

        public ActionResult Sale()
        {
            var createThreedRequest = new CreateThreedRequest
            {
                ApiKey = _apiKey,
                TransactionId = "TestThreedPayment00001",
                TransactionTime = "1443600845",
                Amount = 5499,
                Description = "E-ticaretÖdemesi",
                Currency = "TRY",
                Installment = 1,
                Card = new Card
                {
                    CardHolderName = "Ahmet Mehmet",
                    CardNumber = "4506347011448053",
                    ExpireMonth = "02",
                    ExpireYear = "20",
                    SecurityCode = "000"
                },
                BasketItems = new List<BasketItem>
                {
                    new BasketItem
                    {
                        Description = "BoyamaKalemSeti",
                        ProductCode = "7cefdf61-38cd-4b35-b5f0-4c98c5805d41",
                        Amount = 8750,
                        VatRatio = 18,
                        Count = 1,
                        Url = "http://www.ahmetmarket.com.tr/boyama-kalem-seti"
                    },
                    new BasketItem
                    {
                        Description = "BoyamaKitabı",
                        ProductCode = "7cefdf61-38cd-4b35-b5f0-4c98c5805d41",
                        Amount = 2550,
                        VatRatio = 18,
                        Count = 3,
                        Url = "http://www.ahmetmarket.com.tr/boyama-kitabi"
                    },
                    new BasketItem
                    {
                        Description = "KargoBedeli",
                        Amount = 1000,
                        VatRatio = 18,
                        Count = 1
                    }
                },
                Customer = new Customer
                {
                    Name = "Ahmet",
                    Surname = "Mehmet",
                    Email = "ahmetmehmet@ahmetmarket.com.tr",
                    PhoneNumber = "5337654321",
                    Code = "7cefdf61-38cd-4b35-b5f0-4c98c5805d41"
                },
                ShippingAddress = new ShippingAddress
                {
                    Name = "Ahmet Mehmet",
                    Address = "Kuştepe Mahallesi Mecidiyeköy Yolu Cad. No:12 Trump Towers Kule:2 Kat:11 ŞİŞLİ",
                    Country = "Türkiye",
                    CountryCode = "TUR",
                    City = "İstanbul",
                    CityCode = "34",
                    ZipCode = "34580"
                },
                InvoiceAddress = new InvoiceAddress
                {
                    Name = "Ahmet Mehmet",
                    Address = "Kuştepe Mahallesi Mecidiyeköy Yolu Cad. No:12 Trump Towers Kule:2 Kat:11 ŞİŞLİ",
                    Country = "Türkiye",
                    CountryCode = "TUR",
                    City = "İstanbul",
                    CityCode = "34",
                    ZipCode = "34580"
                },
                Extras = new List<Extra> { new Extra { Key = "INT_SPRS_KODU", Value = "spr_123456789" } },
                SuccessUrl = _baseUrl + "/ThreedPayment/SuccessfulResult",
                FailUrl = _baseUrl + "/ThreedPayment/FailedResult",
                Priority = 1,
                VisitorId = "12312312",
                UserKey = "adasdas2222",
                DiscountAmount = 4010,
                GiftCheqAmount = 5600,
                HashVersion = _hashVersion
            };

            var apiUrl = _hepsipayUrl + "/payment/ThreeDSecureV2";

            var createThreedResponse = _paymentProcessor.CreateThreed(createThreedRequest, apiUrl, _secretKey);

            return Content(createThreedResponse.HtmlForm);
        }

        public ActionResult SuccessfulResult(ThreedSuccessfulResultModel threedSuccessfulResultModel)
        {
            var completeThreedRequest = new CompleteThreedRequest
            {
                EncryptedThreedResult = threedSuccessfulResultModel.EncryptedThreedResult,
                ApiKey = _apiKey,
                HashVersion = _hashVersion
            };

            var apiUrl = _apiUrl + "/payments/complete3dpayment";

            var completeThreedResponse = _paymentProcessor.CompleteThreed(completeThreedRequest, apiUrl, _secretKey);

            var resultModel = new ResultModel
            {
                Amount = completeThreedResponse.Amount,
                ApiKey = completeThreedResponse.ApiKey,
                CardId = completeThreedResponse.CardId,
                Currency = completeThreedResponse.Currency,
                FailUrl = completeThreedResponse.FailUrl,
                SuccessUrl = completeThreedResponse.SuccessUrl,
                Success = completeThreedResponse.Success,
                MessageCode = completeThreedResponse.MessageCode,
                Message = completeThreedResponse.Message,
                UserMessage = completeThreedResponse.UserMessage,
                Installment = completeThreedResponse.Installment,
                TransactionTime = completeThreedResponse.TransactionTime,
                TransactionId = completeThreedResponse.TransactionId,
                SaveCreditCard = completeThreedResponse.SaveCreditCard,
                TransactionType = completeThreedResponse.TransactionType,
                ThreeDHostAddress = completeThreedResponse.ThreeDHostAddress
            };

            return View("Result", resultModel);
        }

        public ActionResult FailedResult(FormCollection formCollection)
        {
            var failedThreedResponse = _paymentProcessor.GetFailedThreedResponse(formCollection, _secretKey);

            var resultModel = new ResultModel
            {
                ApiKey = failedThreedResponse.ApiKey,
                Currency = failedThreedResponse.Currency,
                Success = failedThreedResponse.Success,
                MessageCode = failedThreedResponse.MessageCode,
                Message = failedThreedResponse.Message,
                UserMessage = failedThreedResponse.UserMessage,
                TransactionTime = failedThreedResponse.TransactionTime,
                TransactionId = failedThreedResponse.TransactionId,
                BankResponseCode = failedThreedResponse.BankResponseCode,
                BankResponseMessage = failedThreedResponse.BankResponseMessage
            };
            int installment;
            if (int.TryParse(failedThreedResponse.Installment, out installment))
            {
                resultModel.Installment = installment;
            }
            int amount;
            if (int.TryParse(failedThreedResponse.Amount, out amount))
            {
                resultModel.Amount = amount;
            }
            return View("Result", resultModel);
        }
    }
}